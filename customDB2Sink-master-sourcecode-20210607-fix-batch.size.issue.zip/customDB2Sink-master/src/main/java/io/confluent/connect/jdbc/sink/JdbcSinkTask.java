/*
 * Copyright 2018 Confluent Inc.
 *
 * Licensed under the Confluent Community License (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a copy of the
 * License at
 *
 * http://www.confluent.io/confluent-community-license
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OF ANY KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations under the License.
 */

package io.confluent.connect.jdbc.sink;

import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.connect.errors.ConnectException;
import org.apache.kafka.connect.errors.RetriableException;
import org.apache.kafka.connect.json.JsonConverter;
import org.apache.kafka.connect.sink.SinkRecord;
import org.apache.kafka.connect.sink.SinkTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.sql.BatchUpdateException;
import java.sql.SQLException;
import java.sql.SQLNonTransientConnectionException;
import java.sql.Statement;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;

import io.confluent.connect.jdbc.dialect.DatabaseDialect;
import io.confluent.connect.jdbc.dialect.DatabaseDialects;

public class JdbcSinkTask extends SinkTask {
  private static final Logger log = LoggerFactory.getLogger(JdbcSinkTask.class);

  // Kafka producer writes bad records to configured DLQ topic in case of processing failures.
  protected Producer<byte[], byte[]> dlqProducer;
  DatabaseDialect dialect;
  JdbcSinkConfig config;
  JdbcDbWriter writer;
  int remainingRetries;

  /* Used to serialize the Kafka key and value of the sink record identified as bad
  record because of processing failures. */
  private final JsonConverter converter = new JsonConverter();

  @Override
  public void start(final Map<String, String> props) {
    log.info("Starting JDBC Sink task");
    config = new JdbcSinkConfig(props);
    initWriter();
    remainingRetries = config.maxRetries;
    //initializing JsonConverter
    Map<String, Object> converterConfig = new HashMap<>();
    converterConfig.put("schemas.enable", "false");
    converterConfig.put("schemas.cache.size", 50);
    this.converter.configure(converterConfig, false);
    initDlqProducer();
  }

  void initDlqProducer() {
    if (config.isDlqEnabled()) {
      log.info("Initializing DLQ Kafka Producer");
      dlqProducer = new KafkaProducer<>(config.getDlqProps());
    } else {
      dlqProducer = null;
    }
  }

  void initWriter() {
    if (config.dialectName != null && !config.dialectName.trim().isEmpty()) {
      dialect = DatabaseDialects.create(config.dialectName, config);
    } else {
      dialect = DatabaseDialects.findBestFor(config.connectionUrl, config);
    }
    final DbStructure dbStructure = new DbStructure(dialect);
    log.info("Initializing writer using SQL dialect: {}", dialect.getClass().getSimpleName());
    writer = new JdbcDbWriter(config, dialect, dbStructure);
  }

  @Override
  public void put(Collection<SinkRecord> records) {
    if (records.isEmpty()) {
      return;
    }
    final SinkRecord first = records.iterator().next();
    final int recordsCount = records.size();
    log.debug(
        "Received {} records. First record kafka coordinates:({}-{}-{}). Writing them to the "
        + "database...",
        recordsCount, first.topic(), first.kafkaPartition(), first.kafkaOffset()
    );
    try {
      writer.write(records);
    } catch (SQLNonTransientConnectionException e) {
      // Retrying in the case when connector restarts, allowing to refresh the DataSource.
      retryFailedRecords(records, e);
    } catch (BatchUpdateException buex) {
      long[] updateCounts = buex.getLargeUpdateCounts();
      Iterator<SinkRecord> iterator = records.iterator();
      // Processing current batch records
      for (int i = 0; i < updateCounts.length; i++) {
        // Check which record in the batch is failed
        if (updateCounts[i] == Statement.EXECUTE_FAILED) {
          handleErrors(Collections.singletonList(iterator.next()),
              buex, buex.getMessage());
        } else {
          iterator.next();
        }
      }
      // Processing records present after the current failed batch
      while (iterator.hasNext()) {
        processRemainingRecords(iterator.next());
      }
    } catch (SQLException sqle) {
      // Processing each record without retries and sending to DLQ
      for (SinkRecord record : records) {
        processRemainingRecords(record);
      }
    }
    remainingRetries = config.maxRetries;
  }

  private void retryFailedRecords(Collection<SinkRecord> records, SQLException sqle) {
    log.warn(
        "Write of {} records failed, remainingRetries={}",
        records.size(),
        remainingRetries,
        sqle
    );
    String sqleAllMessages = "";
    for (Throwable e : sqle) {
      sqleAllMessages += e + System.lineSeparator();
    }
    if (remainingRetries == 0) {
      handleErrors(records, new SQLException(sqleAllMessages), sqleAllMessages);
    } else {
      writer.closeQuietly();
      initWriter();
      remainingRetries--;
      context.timeout(config.retryBackoffMs);
      throw new RetriableException(new SQLException(sqleAllMessages));
    }

  }

  @Override
  public void flush(Map<TopicPartition, OffsetAndMetadata> map) {
    // Not necessary
  }

  private void processRemainingRecords(SinkRecord record) {
    try {
      writer.write(Collections.singletonList(record));
    } catch (SQLException e) {
      handleErrors(Collections.singletonList(record),
          e, e.getMessage());
    }
  }

  // Send corrupted record to the DLQ
  void sendFailedRecordToDlq(SinkRecord record, SQLException sqle) {
    byte[] recordKey = null;
    byte[] recordValue = null;
    if (record.key() != null) {
      recordKey = converter.fromConnectData(
          record.topic(),
          record.keySchema(),
          record.key()
      );
    }
    if (record.value() != null) {
      recordValue = converter.fromConnectData(
          record.topic(),
          record.valueSchema(),
          record.value()
      );
    }
    DlqMessageHeader dlqMessageHeader = new DlqMessageHeader(sqle.toString()
        + System.lineSeparator() + sqle.getNextException(), record.topic(),
        record.kafkaPartition(), record.kafkaOffset());
    ProducerRecord<byte[], byte[]> dlqRecord =
        new ProducerRecord<>(config.getDlqTopicName(), record.kafkaPartition(), recordKey,
            recordValue);
    dlqRecord.headers().add(dlqMessageHeader);
    try {
      dlqProducer.send(dlqRecord, (recordMetadata, exception) -> {
        if (exception != null) {
          throw new ConnectException(
            String.format("Failed to write records to dead-letter queue topic=%s.",
                config.getDlqTopicName()),
            exception
          );
        }
      });
    } catch (IllegalStateException e) {
      log.error("Failed to write records to dead-letter queue topic, "
          + "kafka producer has already been closed. Exception={}", e);
    }
  }

  public void stop() {
    log.info("Stopping task");
    try {
      if (dlqProducer != null) {
        dlqProducer.close();
      }
    } catch (Exception e) {
      log.error("Failed to close kafka producer={}", e);
    }
    try {
      writer.closeQuietly();
    } finally {
      try {
        if (dialect != null) {
          dialect.close();
        }
      } catch (Throwable t) {
        log.warn("Error while closing the {} dialect: ", dialect.name(), t);
      } finally {
        dialect = null;
      }
    }
  }

  // Handle behaviour of connector on the basis of behaviorOnError config.
  private void handleErrors(Collection<SinkRecord> records, SQLException ex, String message) {
    if (JdbcSinkConfig.BehaviorOnError.FAIL == config.getBehaviorOnError()) {
      throw new ConnectException(message, ex);
    } else {
      // DLQ is enabled
      if (dlqProducer != null) {
        for (SinkRecord record : records) {
          sendFailedRecordToDlq(record, ex);
        }
      } else {
        // DLQ is not enabled.
        for (SinkRecord record :  records) {
          log.error("Failed to write record with coordinate topic = {}, "
                + "partition = {}, offset = {} due to \n",
              record.topic(),
              record.kafkaPartition(),
              record.kafkaOffset(),
              ex.getNextException()
          );
        }
      }
    }
  }

  @Override
  public String version() {
    return getClass().getPackage().getImplementationVersion();
  }

}
