# Kafka Connect JDBC Connector
[![FOSSA Status](https://app.fossa.io/api/projects/git%2Bhttps%3A%2F%2Fgithub.com%2Fconfluentinc%2Fkafka-connect-jdbc.svg?type=shield)](https://app.fossa.io/projects/git%2Bhttps%3A%2F%2Fgithub.com%2Fconfluentinc%2Fkafka-connect-jdbc?ref=badge_shield)


kafka-connect-jdbc is a [Kafka Connector](http://kafka.apache.org/documentation.html#connect)
for loading data to and from any JDBC-compatible database.

Documentation for this connector can be found [here](http://docs.confluent.io/current/connect/connect-jdbc/docs/index.html).

# Development

To build a development version you'll need a recent version of Kafka as well as a set of upstream Confluent projects, which you'll have to build from their appropriate snapshot branch. See the [FAQ](https://github.com/confluentinc/kafka-connect-jdbc/wiki/FAQ)
for guidance on this process.

You can build kafka-connect-jdbc with Maven using the standard lifecycle phases.

# FAQ

Refer frequently asked questions on Kafka Connect JDBC here -
https://github.com/confluentinc/kafka-connect-jdbc/wiki/FAQ

# Contribute

Contributions can only be accepted if they contain appropriate testing. For example, adding a new dialect of JDBC will require an integration test.

- Source Code: https://github.com/confluentinc/kafka-connect-jdbc
- Issue Tracker: https://github.com/confluentinc/kafka-connect-jdbc/issues

# Information

For more information, check the documentation for the JDBC connector on the [confluent.io](https://docs.confluent.io/current/connect/kafka-connect-jdbc/index.html) website. Questions related to the connector can be asked on [Community Slack](https://launchpass.com/confluentcommunity) or the [Confluent Platform Google Group](https://groups.google.com/forum/#!topic/confluent-platform/).

# License

This project is licensed under the [Confluent Community License](LICENSE).


[![FOSSA Status](https://app.fossa.io/api/projects/git%2Bhttps%3A%2F%2Fgithub.com%2Fconfluentinc%2Fkafka-connect-jdbc.svg?type=large)](https://app.fossa.io/projects/git%2Bhttps%3A%2F%2Fgithub.com%2Fconfluentinc%2Fkafka-connect-jdbc?ref=badge_large)


# Kafka Connect JDBC Sink Connector (Kasikorn Bank)

The existing JDBC Sink connector allows us to export data from Kafka topics to the relational database (eg. DB2). This document explains the customization being brought into the existing JDBC Sink Connector to make it more robust in terms of handling exceptions and more efficient with respect to managing resources (active connections).

We had added the two features in the existing Jdbc Sink connector : 
1. DLQ using KafkaProducer API
2. Support for DB2 connection pooling

## Error handling with DLQ 

Prerequisite : The DLQ Kafka topic should be created prior to running the connector.The number of partitions in the source Kafka topic should be the same as the DLQ topic. This is to ensure that the ordering of the error messages should be maintained.

- With the help of DLQ, we can send failed/corrupt/bad records to a configurable DLQ topic.
- On failure of a batch(SqlException being thrown), each record within the batch will be sequentially processed and the bad records will be individually written in the Kafka topic via the Kafka Producer
- The original Sink records that are realized as bad/malformed will be converted based on the org.apache.kafka.connect.json.JsonConverter Converter and will be written into DLQ topic via Kafka Producer API.
- This connector will allow users to provide Kafka producer configs via the following prefix : [db.deadletterqueue.*].

We had added the following properties for this feature : 

`db.deadletterqueue.bootstrap.servers` : Configure this list to Kafka broker's address(es) to which the Connector should write records failed due to some exception like range partition not found exception etc..This list should be in the form host-1:port-1,host-2:port-2,…host-n:port-n.

`db.deadletterqueue.topic.name` : Set this to the Kafka topic's name to which the Connector should write records failed due to database exception.

``behavior.on.error`` : Behavior on error setting. Must be configured to one of the following:
  
        ``fail`` : Stops the connector when an error occurs while processing records.
  
        ``log`` : Logs the error message and continues to process subsequent records. This is default behaviour of the connector. If DLQ is enabled then record will send to the DLQ Kafka topic, else, failures will be logged as connect logs.

Note : 
1. For enabling DLQ, we have to provide above two config.If we dont specify these two properties then DLQ will not be enabled.
2. You might have to pass the topic name and the field name in the schema in capital letters if the table was created using db2.

## Support for DB2 connection pooling

Connection pooling means that connections are reused rather than created each time a connection is requested. To facilitate connection reuse, a memory cache of database connections, called a connection pool, is maintained by a connection pooling module as a layer on top of any standard JDBC driver product.We are using Hikari connection pooling to make the pool of connections.

The connection had exposed the following config to allow users to set the maximum pool size for connection: 

 `max.connection.pool.size` : The maximum number of active DB connections to be allowed. Lowering the value of this configuration will result in a drop in Connector performance(throughput). By default, the value is 10.

### JDBC Sink Connector official documentation : https://docs.confluent.io/kafka-connect-jdbc/current/sink-connector/index.html
